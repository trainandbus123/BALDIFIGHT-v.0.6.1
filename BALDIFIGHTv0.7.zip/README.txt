Welcome to Baldi's BossFight in Education and Learning! That's me!
Not really, this is a Baldi's Basics Fan Game made by trainandbus123 (youtube.com/@trainandbus123Perth). Created with GameMaker Studio 2 in GML Language.
Thank you for taking the time to read the README!

--WARNING--
This game contains jumpscares, horror elements, and other features that some people might consider a bit spoopy.
I would recommend not playing or playing on a lower volume setting, unless you like these things!
YOU HAVE BEEN WARNED. DON'T SAY THAT I HAVEN'T WARNED YOU, THIS IS THE README. YOU SHOULD'VE READ IT.

--INSTRUCTIONS--
You are the Impostor. Your job is to kill Baldi without dying. You have one life. Get hit and you die. Hit Baldi 5 times to win (More Below.)
Baldi: Jump on his head to do damage and get teleported back to the start area. Do damage 5 times to win. Has 4 head attacks that constantly follow you around based on how far you are into the game. Touching his heads result in a GameOver. Touching parts of his body except the Head result in a GameOver.
Principal: Will give you detention if caught and it might be the best way to do damage to Baldi. Touching the lava he placed around the level results in a GameOver.
Gotta Sweep: If you touch his randomly moving mystery box he will jump out, resulting in a GameOver.
Mrs Pomp: If her timer shown in the top left corner runs out it will trigger a GameOver.

--HOW TO WIN AND LOSE--
How to Win: Hit Baldi's head 5 times. The amount of times you have hit Baldi's head shows up in the bottom left corner.
How to Lose: Hit Gotta Sweep's mystery box, hit Baldi below the head, let one of Baldi's head attacks touch you, touch the Principal's Lava, fall in the void, or run out of time.

--HELPFUL HINTS--
If you move right/left while touching Baldi's head, Baldi will let you pass, resulting in neither damage for you or Baldi.
There are some areas where you can hide and dodge Baldi's Heads.
Baldi's head cannot catch you at the far left of the map unless you stay there for 20 seconds.
You can die to the lava on the bridge by jumping into it from below.
You can die to the void by moving to the left when on the left edge of the map.
